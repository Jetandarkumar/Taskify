
# Taskify
TODO app made in react. 

Run `npm start` to locally start the app. 
